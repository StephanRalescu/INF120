# main.py: the paint calculator
