# paint.py: paint calculations (a module)
