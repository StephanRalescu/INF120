# main.py: score report
